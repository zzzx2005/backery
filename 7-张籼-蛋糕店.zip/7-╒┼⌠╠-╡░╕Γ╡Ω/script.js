let navbar = document.querySelector('.navbar');

document.querySelector('#menu-btn').onclick = () =>{
    navbar.classList.toggle('active');
    searchForm.classList.remove('active');
    cartItem.classList.remove('active');
}

let searchForm = document.querySelector('.search-form');

document.querySelector('#search-btn').onclick = () =>{
    searchForm.classList.toggle('active');
    navbar.classList.remove('active');
    cartItem.classList.remove('active');
}
let cartItem = document.querySelector('.cart-items-container');

document.querySelector('#cart-btn').onclick = () =>{
    cartItem.classList.toggle('active');
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
}
window.onscroll = () =>{
    navbar.classList.remove('active');
    searchForm.classList.remove('active');
    cartItem.classList.remove('active');
}

    let cart = []; // 购物车数组，保存商品对象和数量  
    let totalPrice = 0; // 总价  
      
    // 假设每个商品都有一个唯一的ID来识别  
    function addToCart(productId, quantity, price) {  
        // ...（省略之前的添加到购物车的逻辑）  
        // 这里需要稍微修改一下，使用productId来标识商品  
        let product = cart.find(item => item.productId === productId);  
        if (product) {  
            product.quantity += quantity; // 如果商品已存在，增加数量  
        } else {  
            cart.push({ productId, quantity, price }); // 添加新商品到购物车  
        }  
        updateCartDisplay();  
        updateTotalPrice();  
    }  
      
    function removeFromCart(productId, quantity,is) {  
        let product = cart.find(item => item.productId === productId);  
        if (product) {  
            if (quantity >= product.quantity) {  
                // 如果要移除的数量大于或等于商品现有数量，则移除整个商品  
                cart = cart.filter(item => item.productId !== productId);  
            } else {  
                // 否则，减少商品数量  
                product.quantity -= quantity;  
                // 如果数量为0，则移除商品  
                if (product.quantity === 0) {  
                    cart = cart.filter(item => item.productId !== productId);  
                }  
            }  
            updateCartDisplay();  
            updateTotalPrice();  
        }  
    } 
    
    function removeFromCart2() {  
        const cartItemsElement = document.getElementById('cart-items-container');  
        cartItemsElement.innerHTML = ''; // 清空当前购物车内容
        cart = [];
        totalPrice = 0; 
        document.getElementById('totalPrice').textContent = totalPrice.toFixed(2); // 保留两位小数
    }
      
    function updateCartDisplay() {  
        // ...（省略之前的更新购物车显示的逻辑）  
        // 这里可以根据需要添加更多的显示逻辑，如商品图片、名称等
        const cartItemsElement = document.getElementById('cart-items-container');  
        cartItemsElement.innerHTML = ''; // 清空当前购物车内容  
        cart.forEach(item => {  
            const div = document.createElement('div'); 
            div.className = 'cart-item';
            cartItemsElement.appendChild(div);
            const span = document.createElement('span'); 
            span.className = 'fas fa-times';
            span.onclick = function(){
                removeFromCart(item.productId,1);
            };
            div.appendChild(span);
            cartItemsElement.appendChild(div);
            const img = document.createElement('img'); 
            img.src = `img/${item.productId}.jpg`;
            div.appendChild(img);
            const div2 = document.createElement('div'); 
            div2.className = 'content';
            div.appendChild(div2);
            const h3 = document.createElement('h3'); 
            h3.textContent = `cart item ${item.productId}`;
            div2.appendChild(h3);
            const div3 = document.createElement('div'); 
            div3.className = 'price';
            div3.textContent = `$${item.price}/${item.quantity}`;
            div2.appendChild(div3);   
        });  
    }  
      
    function updateTotalPrice() {  
        totalPrice = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);  
        document.getElementById('totalPrice').textContent = totalPrice.toFixed(2); // 保留两位小数  
    }  

    function search() {  
        const searchInput = document.getElementById('search-box');  
        const searchTerm = searchInput.value.toLowerCase(); // 转换为小写以进行不区分大小写的搜索  
        const cakes = document.getElementById('cakes');
        const pastry = document.getElementById('pastry');  
      
        // 遍历内容区域中的h2元素（或其他你希望搜索的元素）  
        const headers = cakes.getElementsByTagName('h3'); 
        const headers2 = pastry.getElementsByTagName('h3'); 

        for (let i = 0; i < headers.length+headers2.length; i++) {  
            const headerText = headers[i].textContent.toLowerCase(); // 同样转换为小写  
            const headerText2 = headers2[i].textContent.toLowerCase();
            if (headerText.includes(searchTerm)) {  
                // 滚动到匹配的元素  
                headers[i].scrollIntoView({ behavior: 'smooth' }); // 平滑滚动效果  
                break; // 找到第一个匹配的元素后停止搜索（如果需要找到所有匹配的元素，请移除此行）  
            }else if(headerText2.includes(searchTerm)){
                headers2[i].scrollIntoView({ behavior: 'smooth' }); // 平滑滚动效果  
                break; // 找到第一个匹配的元素后停止搜索（如果需要找到所有匹配的元素，请移除此行
            }  
        }  
    }
      
    // 初始调用，这里假设页面加载时就有商品加入购物车（仅为示例）  
    addToCart(1, 1, 52.99);
    addToCart(3, 1, 52.99); // 调用示例，你可以根据需要从HTML元素或其他地方获取这些值  
      
    // 示例：从购物车中移除商品  
    // removeFromCart(1, 1); // 移除产品ID为1的商品1个

 
    document.getElementById('myForm').addEventListener('submit', function(event) {  
        event.preventDefault(); // 阻止表单的默认提交行为  
    
        // 假设你有一个URL可以处理表单数据  
        var url = 'https://example.com/submit-form';  
    
        // 创建一个新的XMLHttpRequest对象  
        var xhr = new XMLHttpRequest();

        var name = document.getElementById("abc_name").value;
        var email = document.getElementById("abc_email").value;
        var number = document.getElementById("abc_number").value;

        // 定义请求完成时的处理函数  
        xhr.onload = function() {  
            
            // 隐藏表单并显示提交消息  
            document.getElementById('myForm').style.display = 'none';
            document.getElementById('message').style.display = 'flex'; 
            document.getElementById('message').textContent = 'name:'+name+',email:'+email+',number:'+number; 
            
        };  
    
        // 定义请求出错时的处理函数  
        xhr.onerror = function() {  
            // 隐藏表单并显示提交消息  
            document.getElementById('myForm').style.display = 'none';
            document.getElementById('message').style.display = 'flex';     
document.getElementById('message').textContent ='You have submitted successfully!  Please confirm the information and wait for us to contact you! name:'+name+',email:'+email+',number:'+number;  
        };  
    
        // 设置请求类型、URL和是否需要发送异步请求  
        xhr.open('POST', url, true);  
    
        // 设置请求头（如果需要的话）  
        // xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');  
    
        // 收集表单数据  
        var formData = new FormData(this);  
    
        // 发送请求  
        xhr.send(formData);  
    });
  

  


     
    
    
    
    
    
    
     
    
    
    
    
    
    

